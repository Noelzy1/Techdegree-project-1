import random


def guess_input():
    while True:
        try:
            guess_input = int(input("Please guess a number between 1-10  "))
            if ((guess_input > 10) or (guess_input < 1)):
                raise ValueError("The number must be between 1-10")
            break
        except ValueError as err:
            print("Oh no! That's not a valid value. Try again...")
            print("({})".format(err))
    return guess_input


def start_game():
    print("---------------------------\nWelcome to the guessing game\n---------------------------")
    number = random.randrange(1,10)
    guess = guess_input()
    attempt_counter = 1
    while guess != number:
        if guess > number:
            print("It's lower")
            guess = guess_input()
            attempt_counter += 1
        elif guess < number:
            print("It's higher")
            guess = guess_input()
            attempt_counter += 1
    print("Got it! Your guess is correct!")
    print("It took you {} attempts".format(attempt_counter))
    print("This is the end of the game")
    return attempt_counter

score = []

print("There is no current high score")
score.append(start_game())
HIGHSCORE = score[0]
play_again = input("Would you like to play again? Y/N  ")
while play_again.lower() == "y":
    score.sort()
    HIGHSCORE = score[0]
    print("\nThe current High Score is {}\n".format(HIGHSCORE))
    score.append(start_game())
    play_again = input("Would you like to play again? Y/N  ")
print("Thank you for playing")