score = []
score.append(5)
score.append(7)
score.append(2)
score.sort()
print(score[0])